package com.sp.glasscalc;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class MainActivity extends Activity {

    private static final String PLUS = "+";
    private static final String MINUS = "\u2212";
    private static final String TIMES = "\u00D7";
    private static final String DIV = "\u00F7";

    private TextView tvExpr;
    private TextView tvResult;

    private String current = "0";
    private double acc = 0;
    private String op = null;
    private boolean newEntry = true;
    private boolean error = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        setContentView(R.layout.activity_main);
        tvExpr = findViewById(R.id.tvExpr);
        tvResult = findViewById(R.id.tvResult);
        refresh();
    }

    public void onDigit(View v) {
        if (error) {
            resetAll();
        }
        String d = ((Button) v).getText().toString();
        if (newEntry || current.equals("0")) {
            current = d;
        } else if (current.length() < 15) {
            current = current + d;
        }
        newEntry = false;
        refresh();
    }

    public void onDot(View v) {
        if (error) {
            resetAll();
        }
        if (newEntry) {
            current = "0.";
            newEntry = false;
        } else if (!current.contains(".")) {
            current = current + ".";
        }
        refresh();
    }

    public void onOperator(View v) {
        if (error) {
            return;
        }
        String selected = ((Button) v).getText().toString();
        if (op != null && !newEntry) {
            if (!calculate()) {
                return;
            }
            current = format(acc);
        } else if (op == null) {
            acc = parse(current);
        }
        op = selected;
        newEntry = true;
        tvExpr.setText(format(acc) + " " + op);
        refresh();
    }

    public void onEquals(View v) {
        if (error || op == null) {
            return;
        }
        double left = acc;
        String usedOp = op;
        String right = current;
        if (!calculate()) {
            return;
        }
        tvExpr.setText(format(left) + " " + usedOp + " " + right + " =");
        current = format(acc);
        op = null;
        newEntry = true;
        refresh();
    }

    public void onClear(View v) {
        resetAll();
        refresh();
    }

    public void onBackspace(View v) {
        if (error) {
            resetAll();
        } else if (!newEntry) {
            if (current.length() <= 1 || (current.length() == 2 && current.startsWith("-"))) {
                current = "0";
            } else {
                current = current.substring(0, current.length() - 1);
            }
        }
        refresh();
    }

    public void onPercent(View v) {
        if (error) {
            return;
        }
        current = format(parse(current) / 100.0);
        newEntry = false;
        refresh();
    }

    public void onNegate(View v) {
        if (error || current.equals("0")) {
            return;
        }
        if (current.startsWith("-")) {
            current = current.substring(1);
        } else {
            current = "-" + current;
        }
        refresh();
    }

    private boolean calculate() {
        double right = parse(current);
        double result;
        if (op.equals(PLUS)) {
            result = acc + right;
        } else if (op.equals(MINUS)) {
            result = acc - right;
        } else if (op.equals(TIMES)) {
            result = acc * right;
        } else {
            if (right == 0) {
                error = true;
                current = "Error";
                op = null;
                newEntry = true;
                tvExpr.setText("");
                refresh();
                return false;
            }
            result = acc / right;
        }
        acc = result;
        return true;
    }

    private void resetAll() {
        current = "0";
        acc = 0;
        op = null;
        newEntry = true;
        error = false;
        tvExpr.setText("");
    }

    private double parse(String s) {
        try {
            return Double.parseDouble(s);
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    private String format(double v) {
        if (v == 0) {
            return "0";
        }
        if (Math.abs(v) >= 1e15 || Double.isNaN(v) || Double.isInfinite(v)) {
            return String.valueOf(v);
        }
        String s = new BigDecimal(v).setScale(10, RoundingMode.HALF_UP)
                .stripTrailingZeros().toPlainString();
        return s;
    }

    private void refresh() {
        tvResult.setText(current);
        int len = current.length();
        if (len > 12) {
            tvResult.setTextSize(30);
        } else if (len > 9) {
            tvResult.setTextSize(40);
        } else if (len > 6) {
            tvResult.setTextSize(52);
        } else {
            tvResult.setTextSize(64);
        }
    }
}
